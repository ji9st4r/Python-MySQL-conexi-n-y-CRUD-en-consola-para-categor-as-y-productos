# FoodieGo - Semana 4: Python + MySQL (CRUD en consola)

Continuación del Mini-ORM FoodieGo: se migra de SQLite a MySQL y se agregan consultas
parametrizadas (%s), validaciones de negocio, transacciones (commit / rollback) y pruebas mínimas.

## Estructura
- `src/` código (database/connection.py, models/*.py, main.py, app_cli.py, pruebas_minimas.py)
- `db/` scripts SQL (esquema, semillas, verificación) y carpeta imports
- `docs/` evidencias
- `.env.example` plantilla de variables (el `.env` real no se sube)
- `requirements.txt` dependencias

## Puesta en marcha (Windows, VS Code)
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env      (y pon tu clave de root en DB_PASSWORD)
```
En MySQL Workbench abre y ejecuta todo `db/foodiego_semana4_mysql.sql`.

## Ejecución
```
python src/database/connection.py   # CP1: SELECT NOW() y tablas
python src/app_cli.py --demo        # demostración del CRUD
python src/app_cli.py               # menú interactivo
python src/pruebas_minimas.py       # CP3: feliz, borde y error
python src/main.py                  # programa original del Mini-ORM (MySQL)
```
Verificación en MySQL: `db/03_verificacion.sql`.

## Equivalencias con el laboratorio (categorías y productos)
- Categoría -> Restaurante (entidad padre; conteo de pedidos por restaurante)
- Producto  -> Pedido (FK a cliente/restaurante/repartidor; total >= 0 y estado válido)
- SKU único -> email único (clientes) y placa única (repartidores)
- Stock = 0 -> total = 0
