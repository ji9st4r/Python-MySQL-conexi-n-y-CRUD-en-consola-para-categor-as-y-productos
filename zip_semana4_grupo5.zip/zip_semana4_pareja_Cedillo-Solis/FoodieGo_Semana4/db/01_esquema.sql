CREATE DATABASE IF NOT EXISTS foodiego_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE foodiego_db;

DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS repartidores;
DROP TABLE IF EXISTS restaurantes;
DROP TABLE IF EXISTS clientes;

CREATE TABLE clientes (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    telefono VARCHAR(20),
    direccion_entrega VARCHAR(255) NOT NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE restaurantes (
    id_restaurante INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    tipo_cocina VARCHAR(50),
    direccion VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    calificacion_promedio DECIMAL(2,1) DEFAULT 0.0,
    CONSTRAINT chk_restaurante_calificacion CHECK (calificacion_promedio >= 0 AND calificacion_promedio <= 5)
) ENGINE=InnoDB;

CREATE TABLE repartidores (
    id_repartidor INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    tipo_vehiculo VARCHAR(30),
    placa VARCHAR(20) UNIQUE,
    estado VARCHAR(20) DEFAULT 'disponible',
    CONSTRAINT chk_repartidor_estado CHECK (estado IN ('disponible','en_ruta','desconectado'))
) ENGINE=InnoDB;

CREATE TABLE pedidos (
    id_pedido INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_restaurante INT NOT NULL,
    id_repartidor INT NULL,
    fecha_pedido DATETIME DEFAULT CURRENT_TIMESTAMP,
    estado VARCHAR(20) DEFAULT 'pendiente',
    total DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_pedido_total CHECK (total >= 0),
    CONSTRAINT chk_pedido_estado CHECK (estado IN ('pendiente','en_preparacion','en_camino','entregado','cancelado')),
    CONSTRAINT fk_pedido_cliente FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_restaurante FOREIGN KEY (id_restaurante) REFERENCES restaurantes(id_restaurante) ON DELETE RESTRICT,
    CONSTRAINT fk_pedido_repartidor FOREIGN KEY (id_repartidor) REFERENCES repartidores(id_repartidor) ON DELETE SET NULL
) ENGINE=InnoDB;
