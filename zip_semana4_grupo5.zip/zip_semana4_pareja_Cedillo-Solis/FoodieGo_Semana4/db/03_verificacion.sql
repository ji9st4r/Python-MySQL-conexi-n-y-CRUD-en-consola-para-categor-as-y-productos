USE foodiego_db;

-- V1. JOIN pedidos - clientes - restaurantes - repartidores
SELECT p.id_pedido, CONCAT(c.nombre, ' ', c.apellido) AS cliente, r.nombre AS restaurante,
       COALESCE(CONCAT(rp.nombre, ' ', rp.apellido), 'Sin asignar') AS repartidor, p.estado, p.total
FROM pedidos p
JOIN clientes c ON c.id_cliente = p.id_cliente
JOIN restaurantes r ON r.id_restaurante = p.id_restaurante
LEFT JOIN repartidores rp ON rp.id_repartidor = p.id_repartidor
ORDER BY p.id_pedido;

-- V2. Conteo total de pedidos por restaurante
SELECT r.nombre AS restaurante, COUNT(p.id_pedido) AS total_pedidos
FROM restaurantes r LEFT JOIN pedidos p ON p.id_restaurante = r.id_restaurante
GROUP BY r.id_restaurante, r.nombre ORDER BY total_pedidos DESC, r.nombre;

-- V3. Pedidos (confirma INSERT y UPDATE)
SELECT id_pedido, id_cliente, id_restaurante, estado, total FROM pedidos ORDER BY id_pedido;

-- V4. Caso error: no debe haber emails duplicados (esperado: 0 filas)
SELECT email, COUNT(*) AS veces FROM clientes GROUP BY email HAVING COUNT(*) > 1;

-- V5. Tablas
SHOW TABLES;

-- V6. Restricciones de pedidos (PK, FK, CHECK)
SELECT constraint_name, constraint_type FROM information_schema.table_constraints
WHERE table_schema = 'foodiego_db' AND table_name = 'pedidos';
