USE foodiego_db;

INSERT INTO clientes (nombre, apellido, email, telefono, direccion_entrega) VALUES
  ('María', 'Rodríguez', 'maria@email.com', '555-1111', 'Av. Principal 123'),
  ('Carlos', 'López', 'carlos@email.com', '555-2222', 'Calle 456');

INSERT INTO restaurantes (nombre, tipo_cocina, direccion, telefono, calificacion_promedio) VALUES
  ('Pizza Italia', 'Italiana', 'Calle Roma 789', '555-3333', 4.5),
  ('Tacos México', 'Mexicana', 'Av. México 321', '555-4444', 4.8);

INSERT INTO repartidores (nombre, apellido, tipo_vehiculo, placa, estado) VALUES
  ('Juan', 'Pérez', 'Moto', 'ABC-123', 'disponible'),
  ('Ana', 'García', 'Bicicleta', 'XYZ-789', 'disponible');

INSERT INTO pedidos (id_cliente, id_restaurante, id_repartidor, estado, total) VALUES
  (1, 1, NULL, 'pendiente', 25.50),
  (2, 2, NULL, 'pendiente', 18.75);

SELECT 'LISTO' AS estado;
SHOW TABLES;
