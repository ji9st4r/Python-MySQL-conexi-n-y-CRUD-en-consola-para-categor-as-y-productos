from models.base_model import Model


class Cliente(Model):
    """Modelo de la tabla 'clientes' (email UNIQUE)."""

    table_name = "clientes"
    primary_key = "id_cliente"
    fields = ["nombre", "apellido", "email", "telefono", "direccion_entrega"]
    search_field = "nombre"

    @classmethod
    def validar(cls, datos):
        datos = dict(datos)
        datos["nombre"] = cls._requerido(datos, "nombre")
        datos["apellido"] = cls._requerido(datos, "apellido")
        datos["direccion_entrega"] = cls._requerido(datos, "direccion_entrega", "Dirección de entrega")
        email = cls._requerido(datos, "email", "Email")
        if "@" not in email or "." not in email.split("@")[-1]:
            raise ValueError("Email inválido (ejemplo: nombre@correo.com)")
        datos["email"] = email.lower()
        telefono = datos.get("telefono")
        datos["telefono"] = str(telefono).strip() if telefono else None
        return datos
