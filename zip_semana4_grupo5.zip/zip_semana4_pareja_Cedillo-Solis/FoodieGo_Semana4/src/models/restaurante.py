from decimal import Decimal, InvalidOperation

from models.base_model import Model
from database.connection import DatabaseConnection


class Restaurante(Model):
    """Modelo de la tabla 'restaurantes'."""

    table_name = "restaurantes"
    primary_key = "id_restaurante"
    fields = ["nombre", "tipo_cocina", "direccion", "telefono", "calificacion_promedio"]
    search_field = "nombre"

    @classmethod
    def validar(cls, datos):
        datos = dict(datos)
        datos["nombre"] = cls._requerido(datos, "nombre")
        datos["direccion"] = cls._requerido(datos, "direccion", "Dirección")
        for campo in ("tipo_cocina", "telefono"):
            valor = datos.get(campo)
            datos[campo] = str(valor).strip() if valor else None
        cal = datos.get("calificacion_promedio")
        cal = 0 if cal is None or str(cal).strip() == "" else cal
        try:
            cal = Decimal(str(cal))
        except InvalidOperation:
            raise ValueError("Calificación inválida: debe ser un número")
        if not cal.is_finite() or cal < 0 or cal > 5:
            raise ValueError("Calificación debe estar entre 0 y 5")
        datos["calificacion_promedio"] = cal.quantize(Decimal("0.1"))
        return datos

    def get_pedidos(self):
        """Obtiene todos los pedidos de este restaurante."""
        from models.pedido import Pedido
        columnas, filas = DatabaseConnection.fetch_all(
            "SELECT * FROM pedidos WHERE id_restaurante = %s ORDER BY fecha_pedido DESC, id_pedido DESC",
            (self.id_restaurante,))
        return Pedido._desde_filas(columnas, filas)

    @classmethod
    def conteo_pedidos(cls):
        """Total de pedidos por restaurante (equivale al conteo por categoría del laboratorio)."""
        query = ("SELECT r.nombre AS restaurante, COUNT(p.id_pedido) AS total_pedidos "
                 "FROM restaurantes r LEFT JOIN pedidos p ON p.id_restaurante = r.id_restaurante "
                 "GROUP BY r.id_restaurante, r.nombre ORDER BY total_pedidos DESC, r.nombre")
        return DatabaseConnection.fetch_all(query)[1]
