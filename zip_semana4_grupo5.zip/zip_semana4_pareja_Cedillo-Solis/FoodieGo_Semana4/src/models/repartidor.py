from models.base_model import Model
from database.connection import DatabaseConnection

ESTADOS_REPARTIDOR = ("disponible", "en_ruta", "desconectado")


class Repartidor(Model):
    """Modelo de la tabla 'repartidores' (placa UNIQUE)."""

    table_name = "repartidores"
    primary_key = "id_repartidor"
    fields = ["nombre", "apellido", "tipo_vehiculo", "placa", "estado"]
    search_field = "nombre"

    @classmethod
    def validar(cls, datos):
        datos = dict(datos)
        datos["nombre"] = cls._requerido(datos, "nombre")
        datos["apellido"] = cls._requerido(datos, "apellido")
        for campo in ("tipo_vehiculo", "placa"):
            valor = datos.get(campo)
            datos[campo] = str(valor).strip() if valor else None
        estado = (datos.get("estado") or "disponible").strip()
        if estado not in ESTADOS_REPARTIDOR:
            raise ValueError(f"Estado de repartidor inválido (use: {', '.join(ESTADOS_REPARTIDOR)})")
        datos["estado"] = estado
        return datos

    def get_pedidos_asignados(self):
        """Obtiene todos los pedidos asignados a este repartidor."""
        from models.pedido import Pedido
        columnas, filas = DatabaseConnection.fetch_all(
            "SELECT * FROM pedidos WHERE id_repartidor = %s ORDER BY fecha_pedido DESC, id_pedido DESC",
            (self.id_repartidor,))
        return Pedido._desde_filas(columnas, filas)

    def asignar_pedido(self, id_pedido):
        """Asigna el pedido y pone al repartidor 'en_ruta' en UNA sola transacción."""
        try:
            with DatabaseConnection.transaction() as cursor:
                cursor.execute("SELECT estado FROM repartidores WHERE id_repartidor = %s", (self.id_repartidor,))
                fila = cursor.fetchone()
                if fila is None:
                    raise ValueError(f"El repartidor id={self.id_repartidor} no existe")
                if fila[0] != "disponible":
                    raise ValueError(f"El repartidor no está disponible (estado: {fila[0]})")
                cursor.execute("SELECT 1 FROM pedidos WHERE id_pedido = %s", (id_pedido,))
                if cursor.fetchone() is None:
                    raise ValueError(f"El pedido id={id_pedido} no existe")
                cursor.execute("UPDATE pedidos SET id_repartidor = %s, estado = 'en_camino' WHERE id_pedido = %s",
                               (self.id_repartidor, id_pedido))
                cursor.execute("UPDATE repartidores SET estado = 'en_ruta' WHERE id_repartidor = %s",
                               (self.id_repartidor,))
        except Exception as e:
            from mysql.connector import Error
            if isinstance(e, Error):
                raise RuntimeError(DatabaseConnection.traducir_error(e, "asignar el pedido")) from e
            raise
        self.estado = "en_ruta"
        print(f"Pedido {id_pedido} asignado a {self.nombre}")
