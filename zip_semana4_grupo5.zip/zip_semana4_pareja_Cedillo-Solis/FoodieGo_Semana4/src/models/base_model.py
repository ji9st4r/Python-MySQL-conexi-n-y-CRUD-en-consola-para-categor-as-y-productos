"""Clase base del Mini-ORM, ahora con MySQL: consultas %s, validaciones y transacciones."""
from mysql.connector import Error

from database.connection import DatabaseConnection


class Model:
    """Clase base de la que heredan todos los modelos.

    Cada clase hija define: table_name, fields (sin el ID), primary_key y search_field.
    Errores de validación -> ValueError. Errores de base de datos -> RuntimeError.
    """

    table_name = None
    fields = []
    primary_key = "id"
    search_field = "nombre"

    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)

    # ---- hooks que redefinen los modelos ----
    @classmethod
    def validar(cls, datos):
        """Valida y normaliza un diccionario de campos. Devuelve el diccionario limpio."""
        return datos

    def validar_referencias(self, cursor):
        """Verifica FK existentes dentro de la misma transacción."""

    # ---- utilidades ----
    @classmethod
    def _desde_filas(cls, columnas, filas):
        return [cls(**dict(zip(columnas, fila))) for fila in filas]

    def _datos(self):
        return {campo: getattr(self, campo, None) for campo in self.fields}

    @staticmethod
    def _requerido(datos, campo, etiqueta=None):
        valor = datos.get(campo)
        if valor is None or not str(valor).strip():
            raise ValueError(f"{etiqueta or campo.capitalize()} requerido")
        return str(valor).strip()

    # ---- CRUD ----
    def save(self):
        """INSERT parametrizado dentro de una transacción (commit / rollback)."""
        datos = self.validar(self._datos())
        for campo, valor in datos.items():
            setattr(self, campo, valor)
        columnas = ", ".join(self.fields)
        marcadores = ", ".join(["%s"] * len(self.fields))
        query = f"INSERT INTO {self.table_name} ({columnas}) VALUES ({marcadores})"
        try:
            with DatabaseConnection.transaction() as cursor:
                self.validar_referencias(cursor)
                cursor.execute(query, tuple(datos[c] for c in self.fields))
                setattr(self, self.primary_key, cursor.lastrowid)
        except Error as e:
            raise RuntimeError(DatabaseConnection.traducir_error(e, f"guardar en {self.table_name}")) from e
        print(f"Registro guardado en {self.table_name} con ID {getattr(self, self.primary_key)}")

    @classmethod
    def all(cls):
        """SELECT * -> lista de objetos."""
        columnas, filas = DatabaseConnection.fetch_all(f"SELECT * FROM {cls.table_name} ORDER BY {cls.primary_key}")
        return cls._desde_filas(columnas, filas)

    @classmethod
    def find_by_id(cls, id_valor):
        """SELECT ... WHERE pk = %s -> un objeto o None."""
        columnas, filas = DatabaseConnection.fetch_all(
            f"SELECT * FROM {cls.table_name} WHERE {cls.primary_key} = %s", (id_valor,))
        return cls._desde_filas(columnas, filas)[0] if filas else None

    @classmethod
    def buscar(cls, texto):
        """Búsqueda LIKE parametrizada (los % literales se escriben %% en SQL con %s)."""
        if texto is None or not str(texto).strip():
            raise ValueError("Escribe al menos un carácter para buscar")
        query = (f"SELECT * FROM {cls.table_name} "
                 f"WHERE {cls.search_field} LIKE CONCAT('%%', %s, '%%') ORDER BY {cls.primary_key}")
        columnas, filas = DatabaseConnection.fetch_all(query, (str(texto).strip(),))
        return cls._desde_filas(columnas, filas)

    def update(self, **kwargs):
        """UPDATE de campos específicos: valida, comprueba existencia y usa transacción."""
        desconocidos = set(kwargs) - set(self.fields)
        if desconocidos:
            raise ValueError(f"Campos no permitidos: {sorted(desconocidos)}")
        id_valor = getattr(self, self.primary_key)
        nuevos = self._datos()
        nuevos.update(kwargs)
        nuevos = self.validar(nuevos)
        cambios = {k: nuevos[k] for k in kwargs}
        set_clause = ", ".join(f"{k} = %s" for k in cambios)
        query = f"UPDATE {self.table_name} SET {set_clause} WHERE {self.primary_key} = %s"
        try:
            with DatabaseConnection.transaction() as cursor:
                cursor.execute(f"SELECT 1 FROM {self.table_name} WHERE {self.primary_key} = %s", (id_valor,))
                if cursor.fetchone() is None:
                    raise ValueError(f"El registro {id_valor} no existe en {self.table_name}")
                cursor.execute(query, tuple(cambios.values()) + (id_valor,))
        except Error as e:
            raise RuntimeError(DatabaseConnection.traducir_error(e, f"actualizar {self.table_name}")) from e
        for campo, valor in cambios.items():
            setattr(self, campo, valor)
        print(f"Registro {id_valor} de {self.table_name} actualizado")

    def delete(self):
        """DELETE: la FK ON DELETE RESTRICT impide borrar registros con pedidos."""
        id_valor = getattr(self, self.primary_key)
        try:
            with DatabaseConnection.transaction() as cursor:
                cursor.execute(f"SELECT 1 FROM {self.table_name} WHERE {self.primary_key} = %s", (id_valor,))
                if cursor.fetchone() is None:
                    raise ValueError(f"El registro {id_valor} no existe en {self.table_name}")
                cursor.execute(f"DELETE FROM {self.table_name} WHERE {self.primary_key} = %s", (id_valor,))
        except Error as e:
            raise RuntimeError(DatabaseConnection.traducir_error(e, f"eliminar de {self.table_name}")) from e
        print(f"Registro {id_valor} eliminado de {self.table_name}")
