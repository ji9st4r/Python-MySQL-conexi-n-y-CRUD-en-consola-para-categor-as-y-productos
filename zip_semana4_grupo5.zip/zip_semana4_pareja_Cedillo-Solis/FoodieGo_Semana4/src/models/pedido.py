from decimal import Decimal, InvalidOperation

from models.base_model import Model
from database.connection import DatabaseConnection

ESTADOS_PEDIDO = ("pendiente", "en_preparacion", "en_camino", "entregado", "cancelado")
TOTAL_MAX = Decimal("99999999.99")


class Pedido(Model):
    """Modelo de la tabla 'pedidos' (tabla central con 3 FK)."""

    table_name = "pedidos"
    primary_key = "id_pedido"
    fields = ["id_cliente", "id_restaurante", "id_repartidor", "estado", "total"]
    search_field = "estado"

    @staticmethod
    def _entero(valor, etiqueta):
        try:
            return int(valor)
        except (TypeError, ValueError):
            raise ValueError(f"{etiqueta} debe ser un número entero")

    @classmethod
    def validar(cls, datos):
        datos = dict(datos)
        datos["id_cliente"] = cls._entero(datos.get("id_cliente"), "ID de cliente")
        datos["id_restaurante"] = cls._entero(datos.get("id_restaurante"), "ID de restaurante")
        rep = datos.get("id_repartidor")
        datos["id_repartidor"] = None if rep in (None, "") else cls._entero(rep, "ID de repartidor")
        estado = (datos.get("estado") or "pendiente").strip()
        if estado not in ESTADOS_PEDIDO:
            raise ValueError(f"Estado de pedido inválido (use: {', '.join(ESTADOS_PEDIDO)})")
        datos["estado"] = estado
        try:
            total = Decimal(str(datos.get("total")))
        except InvalidOperation:
            raise ValueError("Total inválido: debe ser un número")
        if not total.is_finite():
            raise ValueError("Total inválido: debe ser un número finito")
        if total < 0:
            raise ValueError("Total debe ser >= 0")
        if total > TOTAL_MAX:
            raise ValueError(f"Total demasiado alto (máx. {TOTAL_MAX})")
        datos["total"] = total.quantize(Decimal("0.01"))
        return datos

    def validar_referencias(self, cursor):
        """FK existentes: mensaje claro antes de que MySQL rechace el INSERT."""
        revisiones = [("clientes", "id_cliente", self.id_cliente, "Cliente"),
                      ("restaurantes", "id_restaurante", self.id_restaurante, "Restaurante")]
        if self.id_repartidor is not None:
            revisiones.append(("repartidores", "id_repartidor", self.id_repartidor, "Repartidor"))
        consultas = {
            "clientes": "SELECT 1 FROM clientes WHERE id_cliente = %s",
            "restaurantes": "SELECT 1 FROM restaurantes WHERE id_restaurante = %s",
            "repartidores": "SELECT 1 FROM repartidores WHERE id_repartidor = %s",
        }
        for tabla, _, valor, etiqueta in revisiones:
            cursor.execute(consultas[tabla], (valor,))
            if cursor.fetchone() is None:
                raise ValueError(f"{etiqueta} id={valor} no existe (FK inválida)")

    def get_cliente(self):
        from models.cliente import Cliente
        return Cliente.find_by_id(self.id_cliente)

    def get_restaurante(self):
        from models.restaurante import Restaurante
        return Restaurante.find_by_id(self.id_restaurante)

    def get_repartidor(self):
        if self.id_repartidor is None:
            return None
        from models.repartidor import Repartidor
        return Repartidor.find_by_id(self.id_repartidor)

    def detalles_pedido(self):
        """Muestra el pedido con nombres en lugar de IDs."""
        cliente, restaurante, repartidor = self.get_cliente(), self.get_restaurante(), self.get_repartidor()
        print(f"\n{'=' * 50}\nPEDIDO #{self.id_pedido}\n{'=' * 50}")
        print(f"Cliente: {cliente.nombre} {cliente.apellido}")
        print(f"Dirección: {cliente.direccion_entrega}")
        print(f"Restaurante: {restaurante.nombre} ({restaurante.tipo_cocina})")
        print(f"Fecha: {getattr(self, 'fecha_pedido', '-')}")
        print(f"Total: ${self.total}")
        print(f"Estado: {self.estado.upper()}")
        if repartidor:
            print(f"Repartidor: {repartidor.nombre} {repartidor.apellido} - {repartidor.tipo_vehiculo} ({repartidor.placa})")
        else:
            print("Repartidor: Sin asignar")
        print("=" * 50)

    @classmethod
    def listar_join(cls):
        """JOIN pedidos-clientes-restaurantes-repartidores (equivale al JOIN producto-categoría)."""
        query = (
            "SELECT p.id_pedido, CONCAT(c.nombre, ' ', c.apellido) AS cliente, r.nombre AS restaurante, "
            "COALESCE(CONCAT(rp.nombre, ' ', rp.apellido), 'Sin asignar') AS repartidor, p.estado, p.total "
            "FROM pedidos p "
            "JOIN clientes c ON c.id_cliente = p.id_cliente "
            "JOIN restaurantes r ON r.id_restaurante = p.id_restaurante "
            "LEFT JOIN repartidores rp ON rp.id_repartidor = p.id_repartidor "
            "ORDER BY p.id_pedido"
        )
        return DatabaseConnection.fetch_all(query)[1]
