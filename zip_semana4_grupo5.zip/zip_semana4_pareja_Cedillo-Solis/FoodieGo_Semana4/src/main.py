"""Programa principal del Mini-ORM FoodieGo (ahora sobre MySQL). Se puede ejecutar varias veces."""
from datetime import datetime

from database.connection import DatabaseConnection
from models.cliente import Cliente
from models.pedido import Pedido
from models.repartidor import Repartidor
from models.restaurante import Restaurante

print("=" * 60)
print("FOODIEGO - SISTEMA DE PEDIDOS (MySQL)")
print("=" * 60)
DatabaseConnection.initialize_tables()
s = datetime.now().strftime("%H%M%S")

print("\nCREANDO DATOS DE PRUEBA...\n")
cliente1 = Cliente(nombre="María", apellido="Rodríguez", email=f"maria{s}@email.com",
                   telefono="555-1111", direccion_entrega="Av. Principal 123")
cliente1.save()
restaurante1 = Restaurante(nombre=f"Pizza Italia {s}", tipo_cocina="Italiana",
                           direccion="Calle Roma 789", telefono="555-3333", calificacion_promedio=4.5)
restaurante1.save()
repartidor1 = Repartidor(nombre="Juan", apellido="Pérez", tipo_vehiculo="Moto",
                         placa=f"ABC-{s}", estado="disponible")
repartidor1.save()
pedido1 = Pedido(id_cliente=cliente1.id_cliente, id_restaurante=restaurante1.id_restaurante,
                 id_repartidor=None, estado="pendiente", total=25.50)
pedido1.save()

print("\n" + "=" * 60 + "\nCONSULTANDO DATOS...\n")
print("--- CLIENTES ---")
for c in Cliente.all():
    print(f"ID {c.id_cliente}: {c.nombre} {c.apellido} ({c.email})")
print("\n--- RESTAURANTES ---")
for r in Restaurante.all():
    print(f"ID {r.id_restaurante}: {r.nombre} - {r.tipo_cocina} ({r.calificacion_promedio})")
print("\n--- REPARTIDORES ---")
for rep in Repartidor.all():
    print(f"ID {rep.id_repartidor}: {rep.nombre} {rep.apellido} - {rep.tipo_vehiculo} [{rep.estado}]")

print("\n" + "=" * 60 + "\nPROBANDO RELACIONES...\n")
print(f"Pedidos de '{restaurante1.nombre}':")
for p in restaurante1.get_pedidos():
    print(f"  - Pedido #{p.id_pedido} - Total: ${p.total}")
print(f"\nAsignando repartidor al pedido #{pedido1.id_pedido}...")
repartidor1.asignar_pedido(pedido1.id_pedido)
Pedido.find_by_id(pedido1.id_pedido).detalles_pedido()

print("\n" + "=" * 60 + "\nSISTEMA COMPLETO FUNCIONANDO\n" + "=" * 60)
print(f"Total clientes: {len(Cliente.all())}")
print(f"Total restaurantes: {len(Restaurante.all())}")
print(f"Total repartidores: {len(Repartidor.all())}")
print(f"Total pedidos: {len(Pedido.all())}")
