"""Conexión a MySQL para FoodieGo (continuación del Mini-ORM: de SQLite a MySQL)."""
import os
from contextlib import contextmanager

import mysql.connector
from mysql.connector import Error
from dotenv import load_dotenv

load_dotenv()


class DatabaseConnection:
    """Maneja la conexión MySQL: credenciales en .env, consultas %s y transacciones."""

    @classmethod
    def get_connection(cls):
        """Devuelve una conexión con autocommit desactivado (commit/rollback manual)."""
        usuario = os.getenv("DB_USER", "")
        if not usuario:
            raise RuntimeError("Falta DB_USER: crea tu archivo .env a partir de .env.example")
        try:
            return mysql.connector.connect(
                host=os.getenv("DB_HOST", "127.0.0.1"),
                port=int(os.getenv("DB_PORT", 3306)),
                user=usuario,
                password=os.getenv("DB_PASSWORD", ""),
                database=os.getenv("DB_NAME", "foodiego_db"),
                autocommit=False,
            )
        except Error as e:
            raise RuntimeError(f"Error de conexión MySQL: {e}") from e

    @classmethod
    @contextmanager
    def transaction(cls):
        """Entrega un cursor. COMMIT si el bloque termina bien, ROLLBACK ante cualquier error."""
        conn = cls.get_connection()
        cursor = conn.cursor()
        try:
            yield cursor
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            cursor.close()
            conn.close()

    @classmethod
    def fetch_all(cls, query, params=()):
        """Ejecuta un SELECT parametrizado. Devuelve (columnas, filas)."""
        conn = cls.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            columnas = [d[0] for d in cursor.description]
            return columnas, cursor.fetchall()
        except Error as e:
            raise RuntimeError(cls.traducir_error(e, "consultar")) from e
        finally:
            cursor.close()
            conn.close()

    @staticmethod
    def traducir_error(e, contexto):
        """Convierte errores de MySQL en mensajes claros (errores de BD, no de validación)."""
        errno = getattr(e, "errno", None)
        if errno == 1062:
            detalle = "valor duplicado (email o placa ya existe)"
        elif errno == 1452:
            detalle = "FK inexistente (el cliente, restaurante o repartidor indicado no existe)"
        elif errno == 1451:
            detalle = "el registro tiene pedidos u otros datos relacionados (FK); no se puede eliminar"
        elif errno == 3819:
            detalle = "viola una restricción CHECK (total >= 0, calificación 0-5 o estado válido)"
        elif errno == 1048:
            detalle = "un campo obligatorio llegó vacío (NOT NULL)"
        else:
            detalle = str(e)
        return f"No se pudo {contexto}: {detalle}"

    @classmethod
    def initialize_tables(cls):
        """Comprueba la conexión y que existan las 4 tablas (se crean con db/01_esquema.sql)."""
        _, filas = cls.fetch_all("SHOW TABLES")
        existentes = {f[0] for f in filas}
        faltan = {"clientes", "restaurantes", "repartidores", "pedidos"} - existentes
        if faltan:
            raise RuntimeError(f"Faltan tablas {sorted(faltan)}: ejecuta primero db/01_esquema.sql")
        print("Conexión OK - tablas:", ", ".join(sorted(existentes)))


if __name__ == "__main__":
    # Prueba de conexión (CP1): python src/database/connection.py
    _, r = DatabaseConnection.fetch_all("SELECT NOW()")
    print("SELECT NOW() ->", r[0][0])
    DatabaseConnection.initialize_tables()
