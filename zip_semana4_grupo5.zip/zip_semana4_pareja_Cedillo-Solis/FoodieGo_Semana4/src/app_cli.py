"""Consola de FoodieGo - Semana 4.  Uso:  python src/app_cli.py [--demo]"""
import sys
from datetime import datetime

from database.connection import DatabaseConnection
from models.cliente import Cliente
from models.pedido import Pedido
from models.repartidor import Repartidor
from models.restaurante import Restaurante


def _imprimir(filas):
    if not filas:
        print("  (sin resultados)")
    for f in filas:
        print(" ", f)


def _entero(texto):
    try:
        return int(input(texto).strip())
    except ValueError:
        raise ValueError("Debes escribir un número entero")


def ejecutar(accion):
    """Separa los errores de validación (ValueError) de los de base de datos (RuntimeError)."""
    try:
        accion()
    except ValueError as e:
        print(f"[VALIDACIÓN] {e}")
    except RuntimeError as e:
        print(f"[BASE DE DATOS] {e}")


def _crear_restaurante():
    Restaurante(nombre=input("Nombre: "), tipo_cocina=input("Tipo de cocina: "),
                direccion=input("Dirección: "), telefono=input("Teléfono: "),
                calificacion_promedio=input("Calificación (0-5): ") or 0).save()


def _crear_cliente():
    Cliente(nombre=input("Nombre: "), apellido=input("Apellido: "), email=input("Email: "),
            telefono=input("Teléfono: "), direccion_entrega=input("Dirección de entrega: ")).save()


def _crear_repartidor():
    Repartidor(nombre=input("Nombre: "), apellido=input("Apellido: "),
               tipo_vehiculo=input("Vehículo: "), placa=input("Placa: "), estado="disponible").save()


def _crear_pedido():
    Pedido(id_cliente=_entero("ID cliente: "), id_restaurante=_entero("ID restaurante: "),
           id_repartidor=None, estado="pendiente", total=input("Total: ")).save()


def _actualizar_pedido():
    pedido = Pedido.find_by_id(_entero("ID pedido: "))
    if pedido is None:
        raise ValueError("El pedido no existe")
    pedido.update(total=input("Nuevo total: "), estado=input("Nuevo estado: "))


def _eliminar(modelo, etiqueta):
    obj = modelo.find_by_id(_entero(f"ID de {etiqueta} a eliminar: "))
    if obj is None:
        raise ValueError(f"El {etiqueta} no existe")
    if input("¿Seguro? (s/N): ").strip().lower() != "s":
        print("Operación cancelada")
        return
    obj.delete()


def _asignar():
    rep = Repartidor.find_by_id(_entero("ID repartidor: "))
    if rep is None:
        raise ValueError("El repartidor no existe")
    rep.asignar_pedido(_entero("ID pedido: "))


def _buscar(modelo):
    for o in modelo.buscar(input("Buscar: ")):
        print(" ", o.__dict__)


def menu():
    opciones = {
        "1": ("Crear restaurante", _crear_restaurante),
        "2": ("Listar restaurantes", lambda: _imprimir([(r.id_restaurante, r.nombre, r.tipo_cocina, r.calificacion_promedio) for r in Restaurante.all()])),
        "3": ("Buscar restaurantes por nombre", lambda: _buscar(Restaurante)),
        "4": ("Eliminar restaurante", lambda: _eliminar(Restaurante, "restaurante")),
        "5": ("Crear cliente", _crear_cliente),
        "6": ("Listar clientes", lambda: _imprimir([(c.id_cliente, c.nombre, c.apellido, c.email) for c in Cliente.all()])),
        "7": ("Crear repartidor", _crear_repartidor),
        "8": ("Listar repartidores", lambda: _imprimir([(r.id_repartidor, r.nombre, r.apellido, r.estado) for r in Repartidor.all()])),
        "9": ("Crear pedido", _crear_pedido),
        "10": ("Actualizar total/estado de pedido", _actualizar_pedido),
        "11": ("Asignar repartidor a pedido", _asignar),
        "12": ("Listar pedidos (JOIN)", lambda: _imprimir(Pedido.listar_join())),
        "13": ("Eliminar pedido", lambda: _eliminar(Pedido, "pedido")),
        "14": ("Conteo de pedidos por restaurante", lambda: _imprimir(Restaurante.conteo_pedidos())),
    }
    while True:
        print("\n=== FoodieGo - Consola ===")
        for k, (texto, _) in opciones.items():
            print(f"{k}. {texto}")
        print("0. Salir")
        op = input("Opción: ").strip()
        if op == "0":
            break
        if op in opciones:
            ejecutar(opciones[op][1])
        else:
            print("Opción no válida")


def demo():
    print("--- Demo CRUD Consola FoodieGo ---")
    sufijo = datetime.now().strftime("%H%M%S")
    rest = Restaurante(nombre=f"Burger Demo {sufijo}", tipo_cocina="Fast Food",
                       direccion="Av. Central 100", telefono="555-5555", calificacion_promedio=4.2)
    rest.save()
    cli = Cliente(nombre="Lucía", apellido="Mora", email=f"lucia{sufijo}@email.com",
                  telefono="555-6666", direccion_entrega="Calle 10 y Av. 5")
    cli.save()
    rep = Repartidor(nombre="Pedro", apellido="Salas", tipo_vehiculo="Moto",
                     placa=f"DM-{sufijo}", estado="disponible")
    rep.save()
    ped = Pedido(id_cliente=cli.id_cliente, id_restaurante=rest.id_restaurante,
                 id_repartidor=None, estado="pendiente", total=18.99)
    ped.save()
    ped.update(total=19.99, estado="en_preparacion")
    rep.asignar_pedido(ped.id_pedido)
    print("Pedidos (JOIN):")
    _imprimir(Pedido.listar_join())
    print("Pedidos por restaurante:")
    _imprimir(Restaurante.conteo_pedidos())


if __name__ == "__main__":
    ejecutar(DatabaseConnection.initialize_tables)
    if "--demo" in sys.argv:
        ejecutar(demo)
    else:
        menu()
