"""Pruebas mínimas (feliz, borde, error). Uso:  python src/pruebas_minimas.py
Guarda la salida en docs/salida_pruebas_<fecha>.txt."""
import sys
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from database.connection import DatabaseConnection
from models.cliente import Cliente
from models.pedido import Pedido
from models.restaurante import Restaurante

DOCS = Path(__file__).resolve().parent.parent / "docs"
_lineas = []


def log(msg=""):
    print(msg)
    _lineas.append(str(msg))


def _contar(tabla_sql, params=()):
    return DatabaseConnection.fetch_all(tabla_sql, params)[1][0][0]


def _nuevo_cliente(ts, etiqueta):
    c = Cliente(nombre=etiqueta, apellido="Prueba", email=f"{etiqueta.lower()}{ts}@email.com",
                telefono="555-0000", direccion_entrega="Calle de Prueba 1")
    c.save()
    return c


def caso_feliz(ts):
    log("== CASO FELIZ: crear, actualizar y listar con JOIN ==")
    rest = Restaurante(nombre=f"Restaurante Prueba {ts}", tipo_cocina="Italiana",
                       direccion="Calle Roma 789", telefono="555-3333", calificacion_promedio=4.5)
    rest.save()
    cli = _nuevo_cliente(ts, "Feliz")
    ped = Pedido(id_cliente=cli.id_cliente, id_restaurante=rest.id_restaurante,
                 id_repartidor=None, estado="pendiente", total=25.50)
    ped.save()
    ped.update(total=29.90, estado="en_preparacion")
    fila = [f for f in Pedido.listar_join() if f[0] == ped.id_pedido]
    log(f"JOIN -> {fila[0] if fila else None}")
    return bool(fila) and Decimal(str(fila[0][5])) == Decimal("29.90") and fila[0][4] == "en_preparacion"


def caso_borde(ts):
    log("== CASO BORDE: total = 0 y búsqueda vacía ==")
    rest = Restaurante(nombre=f"Borde Resto {ts}", tipo_cocina="Mexicana",
                       direccion="Av. México 321", telefono="555-4444", calificacion_promedio=0)
    rest.save()
    cli = _nuevo_cliente(ts, "Borde")
    ped = Pedido(id_cliente=cli.id_cliente, id_restaurante=rest.id_restaurante,
                 id_repartidor=None, estado="pendiente", total=0)
    ped.save()
    guardado = Pedido.find_by_id(ped.id_pedido)
    log(f"Pedido con total 0 -> id={guardado.id_pedido}, total={guardado.total}")
    ok_total = guardado is not None and Decimal(str(guardado.total)) == 0
    try:
        Restaurante.buscar("")
        log("ERROR: la búsqueda vacía no fue controlada")
        ok_vacia = False
    except ValueError as e:
        log(f"Búsqueda vacía controlada: {e}")
        ok_vacia = True
    sin = Restaurante.buscar("zzzz_no_existe")
    log(f"Búsqueda sin coincidencias -> {len(sin)} resultado(s)")
    return ok_total and ok_vacia and len(sin) == 0


def caso_error(ts):
    log("== CASO ERROR: email duplicado, FK inexistente y borrado con pedidos (rollback) ==")
    rest = Restaurante(nombre=f"Error Resto {ts}", tipo_cocina="Fast Food",
                       direccion="Av. Error 1", telefono="555-9999", calificacion_promedio=3)
    rest.save()
    cli = _nuevo_cliente(ts, "Error")
    Pedido(id_cliente=cli.id_cliente, id_restaurante=rest.id_restaurante,
           id_repartidor=None, estado="pendiente", total=10).save()
    # 1) UNIQUE: email duplicado
    ok_dup = False
    try:
        Cliente(nombre="Copia", apellido="Dup", email=cli.email, telefono="1",
                direccion_entrega="Calle 2").save()
    except RuntimeError as e:
        n = _contar("SELECT COUNT(*) FROM clientes WHERE email = %s", (cli.email,))
        log(f"Email duplicado controlado: {e}")
        log(f"Filas con ese email tras el rollback: {n} (esperado 1)")
        ok_dup = n == 1
    # 2) FK inexistente
    ok_fk = False
    antes = _contar("SELECT COUNT(*) FROM pedidos")
    try:
        Pedido(id_cliente=999999, id_restaurante=rest.id_restaurante, id_repartidor=None,
               estado="pendiente", total=5).save()
    except (ValueError, RuntimeError) as e:
        despues = _contar("SELECT COUNT(*) FROM pedidos")
        log(f"FK inexistente controlada: {e}")
        log(f"Pedidos antes: {antes} / después: {despues} (deben ser iguales)")
        ok_fk = antes == despues
    # 3) FK RESTRICT: no se puede borrar un restaurante con pedidos
    ok_del = False
    try:
        rest.delete()
    except RuntimeError as e:
        existe = Restaurante.find_by_id(rest.id_restaurante) is not None
        log(f"Borrado bloqueado por FK: {e}")
        log(f"El restaurante sigue existiendo tras el rollback: {existe}")
        ok_del = existe
    return ok_dup and ok_fk and ok_del


def main():
    ahora = datetime.now()
    ts = ahora.strftime("%H%M%S")
    log(f"Pruebas mínimas Semana 4 (FoodieGo) - {ahora:%Y-%m-%d %H:%M:%S}")
    resultados = {}
    for nombre, caso in (("feliz", caso_feliz), ("borde", caso_borde), ("error", caso_error)):
        try:
            resultados[nombre] = bool(caso(ts))
        except Exception as e:
            log(f"Excepción inesperada en caso {nombre}: {e}")
            resultados[nombre] = False
        log(f"--> caso {nombre}: {'PASA' if resultados[nombre] else 'FALLA'}\n")
    log("RESUMEN: " + ", ".join(f"{k}={'PASA' if v else 'FALLA'}" for k, v in resultados.items()))
    DOCS.mkdir(exist_ok=True)
    destino = DOCS / f"salida_pruebas_{ahora:%Y%m%d_%H%M%S}.txt"
    destino.write_text("\n".join(_lineas), encoding="utf-8")
    print(f"Guardado en {destino}")
    return 0 if all(resultados.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
